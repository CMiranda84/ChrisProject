class Question
{
    
    constructor(text, image, options, correctAnswer, category){
        this.text = text;
        this.image = image;
        this.options = options;
        this.corretAnswer = correctAnswer;
        this.category = category;
    }
    
}